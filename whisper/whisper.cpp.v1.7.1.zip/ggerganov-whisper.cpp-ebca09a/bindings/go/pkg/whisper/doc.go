/*
This is the higher-level speech-to-text whisper.cpp API for go
*/
package whisper
