#include "whisper.h"

int main(void) {}
