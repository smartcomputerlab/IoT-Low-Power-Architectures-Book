package io.github.ggerganov.whispercpp.ggml;

public class GgmlTensor {
}
